var searchData=
[
  ['numero',['numero',['../classNoDeInteiro.html#a2d0cc29721104ab1a3c607537b274e85',1,'NoDeInteiro']]]
];
