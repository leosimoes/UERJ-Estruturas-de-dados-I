var searchData=
[
  ['pilhaencadeadadeinteiros_2eh',['PilhaEncadeadaDeInteiros.h',['../PilhaEncadeadaDeInteiros_8h.html',1,'']]],
  ['pilhasequencialdeinteiros_2eh',['PilhaSequencialDeInteiros.h',['../PilhaSequencialDeInteiros_8h.html',1,'']]]
];
