var searchData=
[
  ['tam_5fmax',['TAM_MAX',['../DequeSequencialDeInteiros_8h.html#ac0cf2902c27019004022f788b44d0f5e',1,'TAM_MAX():&#160;DequeSequencialDeInteiros.h'],['../FilaSequencialDeInteiros_8h.html#ac0cf2902c27019004022f788b44d0f5e',1,'TAM_MAX():&#160;FilaSequencialDeInteiros.h'],['../ListaSequencialDeInteiros_8h.html#ac0cf2902c27019004022f788b44d0f5e',1,'TAM_MAX():&#160;ListaSequencialDeInteiros.h'],['../PilhaSequencialDeInteiros_8h.html#ac0cf2902c27019004022f788b44d0f5e',1,'TAM_MAX():&#160;PilhaSequencialDeInteiros.h']]]
];
