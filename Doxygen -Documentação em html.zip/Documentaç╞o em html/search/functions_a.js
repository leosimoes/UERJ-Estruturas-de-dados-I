var searchData=
[
  ['pilhaencadeadadeinteiros',['PilhaEncadeadaDeInteiros',['../classPilhaEncadeadaDeInteiros.html#a5f38bc675d3c4ccefc96e8a78afa860f',1,'PilhaEncadeadaDeInteiros::PilhaEncadeadaDeInteiros()'],['../classPilhaEncadeadaDeInteiros.html#a500a0bed94efb1dd405044d6953240be',1,'PilhaEncadeadaDeInteiros::PilhaEncadeadaDeInteiros(Extremidade extremidade)']]],
  ['pilhasequencialdeinteiros',['PilhaSequencialDeInteiros',['../classPilhaSequencialDeInteiros.html#a439e95937ec14a95891616c7dd3e4309',1,'PilhaSequencialDeInteiros::PilhaSequencialDeInteiros()'],['../classPilhaSequencialDeInteiros.html#a2dc46874e750a71b27b0ccf460b7fcf4',1,'PilhaSequencialDeInteiros::PilhaSequencialDeInteiros(Extremidade extremidade)']]],
  ['pop',['pop',['../classPilhaEncadeadaDeInteiros.html#a51b54527936ad7b7761e365c1cdf960d',1,'PilhaEncadeadaDeInteiros::pop()'],['../classPilhaSequencialDeInteiros.html#a24e20a00043c83ec3a41e38f4481f59b',1,'PilhaSequencialDeInteiros::pop()']]],
  ['push',['push',['../classPilhaEncadeadaDeInteiros.html#a0aa7f63f04252860fed36773cc8c0a1d',1,'PilhaEncadeadaDeInteiros::push()'],['../classPilhaSequencialDeInteiros.html#a1a57bd852dc1b9976b129bd4fdfed9d5',1,'PilhaSequencialDeInteiros::push()']]]
];
