var searchData=
[
  ['setnumero',['setNumero',['../classNoDeInteiro.html#a4ebd62e963233a7043fe0e231848a8c9',1,'NoDeInteiro']]],
  ['setproximo',['setProximo',['../classNoDeInteiro.html#a35d10ba9e61d86dfad42ef83a88d0646',1,'NoDeInteiro']]]
];
