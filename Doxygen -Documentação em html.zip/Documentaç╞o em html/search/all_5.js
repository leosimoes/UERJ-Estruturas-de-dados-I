var searchData=
[
  ['getnumero',['getNumero',['../classNoDeInteiro.html#ae9d1bdc741bd4f63df372ea190af3b32',1,'NoDeInteiro']]],
  ['getproximo',['getProximo',['../classNoDeInteiro.html#a1883157429cb328c721ab97d02c0f77e',1,'NoDeInteiro']]]
];
