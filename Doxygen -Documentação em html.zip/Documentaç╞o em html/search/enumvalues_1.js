var searchData=
[
  ['esquerda',['esquerda',['../Extremidade_8h.html#aad765cf3f35f73a4d51ff45a49135e2baea420fe1132d513235c986a32d9fb2dc',1,'Extremidade.h']]]
];
