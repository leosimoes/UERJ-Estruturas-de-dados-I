var searchData=
[
  ['direita',['direita',['../Extremidade_8h.html#aad765cf3f35f73a4d51ff45a49135e2ba93c403d746342f96a463e9449952f8a7',1,'Extremidade.h']]]
];
