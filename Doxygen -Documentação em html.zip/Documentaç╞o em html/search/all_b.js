var searchData=
[
  ['removerdireita',['removerDireita',['../classDequeEncadeadoDeInteiros.html#a5f544dc703bc18c8192787f36cfa1f00',1,'DequeEncadeadoDeInteiros::removerDireita()'],['../classDequeSequencialDeInteiros.html#a50e393f14f9a786d21da267c58be0662',1,'DequeSequencialDeInteiros::removerDireita()']]],
  ['removerelemento',['removerElemento',['../classListaEncadeadaDeInteiros.html#a16b110c2ddfc82bbf7c92a8cf489ad68',1,'ListaEncadeadaDeInteiros::removerElemento()'],['../classListaSequencialDeInteiros.html#a4eef734a02959971659be725813408a7',1,'ListaSequencialDeInteiros::removerElemento()']]],
  ['removeresquerda',['removerEsquerda',['../classDequeEncadeadoDeInteiros.html#a86406898032514d3cd2ef65bf0f5d355',1,'DequeEncadeadoDeInteiros::removerEsquerda()'],['../classDequeSequencialDeInteiros.html#afc779ec13bb83f29166d0e471766b537',1,'DequeSequencialDeInteiros::removerEsquerda()']]],
  ['removerfinal',['removerFinal',['../classListaEncadeadaDeInteiros.html#acd7c8f4a5580ad14cc3903a3aa1c08bb',1,'ListaEncadeadaDeInteiros::removerFinal()'],['../classListaSequencialDeInteiros.html#ac966145395883cf2b1ad005fa8bf89a7',1,'ListaSequencialDeInteiros::removerFinal()']]],
  ['removerinicio',['removerInicio',['../classListaEncadeadaDeInteiros.html#a8981cf8aa59e222b2618b4942717ae8f',1,'ListaEncadeadaDeInteiros::removerInicio()'],['../classListaSequencialDeInteiros.html#acb3faaa266b4638c21075d875ec10eee',1,'ListaSequencialDeInteiros::removerInicio()']]]
];
