var searchData=
[
  ['buscarelemento',['buscarElemento',['../classListaEncadeadaDeInteiros.html#acba08ef7872405ceeac62127af715917',1,'ListaEncadeadaDeInteiros::buscarElemento()'],['../classListaSequencialDeInteiros.html#a2af5946fafa9a06c7d218774b5e88a12',1,'ListaSequencialDeInteiros::buscarElemento()']]]
];
