var searchData=
[
  ['inicioptr',['inicioPtr',['../classDequeEncadeadoDeInteiros.html#a19fb128114b7a8fbb376db0de0d8ec31',1,'DequeEncadeadoDeInteiros::inicioPtr()'],['../classFilaEncadeadaDeInteiros.html#a471f1833d0c75dfdc2150f7363ef139e',1,'FilaEncadeadaDeInteiros::inicioPtr()'],['../classListaEncadeadaDeInteiros.html#a044e55e3ff451dacfde080a6e5ef13d9',1,'ListaEncadeadaDeInteiros::inicioPtr()'],['../classPilhaEncadeadaDeInteiros.html#a62d3263b9acf994ae455e27d9d70b1cc',1,'PilhaEncadeadaDeInteiros::inicioPtr()']]]
];
