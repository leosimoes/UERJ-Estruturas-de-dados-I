var searchData=
[
  ['pilhaencadeadadeinteiros',['PilhaEncadeadaDeInteiros',['../classPilhaEncadeadaDeInteiros.html',1,'']]],
  ['pilhasequencialdeinteiros',['PilhaSequencialDeInteiros',['../classPilhaSequencialDeInteiros.html',1,'']]]
];
