var searchData=
[
  ['extremidade',['extremidade',['../classDequeSequencialDeInteiros.html#a5b928d78c34988abba4fe82122de5f70',1,'DequeSequencialDeInteiros::extremidade()'],['../classFilaEncadeadaDeInteiros.html#a8f7de803e8f60c288d88146f46b6911d',1,'FilaEncadeadaDeInteiros::extremidade()'],['../classFilaSequencialDeInteiros.html#a209a78913bd1c81232056a7458af1e65',1,'FilaSequencialDeInteiros::extremidade()'],['../classPilhaEncadeadaDeInteiros.html#a1229d267053efdbe5497ba2359ca6a98',1,'PilhaEncadeadaDeInteiros::extremidade()'],['../classPilhaSequencialDeInteiros.html#a1dc788aecb84569d5a6d160cff3ec86b',1,'PilhaSequencialDeInteiros::extremidade()']]]
];
